<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Hola Rena</title>
</head>
<body>
<?php
// Este bucle va desde 10 hasta 100, aumentando de 10 en 10
for ($tamaño = 10; $tamaño <= 100; $tamaño = $tamaño + 10) {
    echo "<p style='font-size: " . $tamaño . "px;'>hola rena</p>";
}
?>

</body>
</html>

